package com.zenscale.zencrm_2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Zencrm2ApplicationTests {

    @Test
    void contextLoads() {

    }




}
