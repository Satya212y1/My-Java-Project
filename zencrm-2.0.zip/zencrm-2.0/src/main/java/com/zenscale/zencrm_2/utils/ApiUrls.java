package com.zenscale.zencrm_2.utils;

public class ApiUrls {



    public static final String base_url_registration = "https://ppc.zenscale.in:9001/";
//    public static final String base_url_registration = "http://192.168.1.171:9001/";
    public static final String url_get_comapany = "api/registration/get_company_code";
    public static final String url_get_read_user = "api/registration/user_contact/read_by_uid";
    public static final String url_get_read_all_user = "api/registration/user/read_users";






}
